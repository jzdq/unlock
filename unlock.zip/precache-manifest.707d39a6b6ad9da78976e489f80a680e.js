self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "25a25dbcfa6e1deb700b",
    "url": "css/app.3f25f0c2.css"
  },
  {
    "revision": "23df87582d0b2ba5950a",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "fe2dba812e348a48b84b64d94cbb4e4d",
    "url": "index.html"
  },
  {
    "revision": "4b79d14a183ba8e1cc07223a36fc4319",
    "url": "js/0.848b6935.worker.js"
  },
  {
    "revision": "25a25dbcfa6e1deb700b",
    "url": "js/app.1b22116f.js"
  },
  {
    "revision": "23df87582d0b2ba5950a",
    "url": "js/chunk-vendors.6ee22c12.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);